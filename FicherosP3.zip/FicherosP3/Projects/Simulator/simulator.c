#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
	/* ... To be completed ... */

	return 0;
}

